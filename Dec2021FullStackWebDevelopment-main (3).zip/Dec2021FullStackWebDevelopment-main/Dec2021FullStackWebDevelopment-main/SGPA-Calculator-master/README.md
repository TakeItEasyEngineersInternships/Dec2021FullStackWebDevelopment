# SGPA-Calculator

This is an android application which calculates SGPA using the percantage of a student. This is built for students studying in colleges under VTU university.
